
sudo docker container attach hmi2



