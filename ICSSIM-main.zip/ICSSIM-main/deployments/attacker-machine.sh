
sudo docker container attach attacker-machine



