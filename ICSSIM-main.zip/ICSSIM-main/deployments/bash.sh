
sudo docker-compose exec $1 bash



