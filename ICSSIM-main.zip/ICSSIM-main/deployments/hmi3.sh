
sudo docker container attach hmi3



