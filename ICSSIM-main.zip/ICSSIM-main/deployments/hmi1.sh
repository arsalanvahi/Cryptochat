
sudo docker container attach hmi1



