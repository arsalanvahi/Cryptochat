#!/bin/bash

#cd src
sudo ls
